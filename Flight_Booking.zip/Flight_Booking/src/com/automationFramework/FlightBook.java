package com.automationFramework;

import java.util.concurrent.TimeUnit;

import org.openqa.selenium.By;
import org.openqa.selenium.JavascriptExecutor;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.chrome.ChromeDriver;
import org.testng.annotations.AfterTest;
import org.testng.annotations.BeforeTest;
import org.testng.annotations.Test;

import com.pageObjects.*;

public class FlightBook {
	private static WebDriver driver;
	@BeforeTest
	public void InitiateDriver() throws Exception 
	{
		driver = new ChromeDriver();
		driver.manage().timeouts().implicitlyWait(30, TimeUnit.SECONDS);
	
		//Launch the home page
		driver.get("https://www.southwest.com");
		driver.manage().timeouts().implicitlyWait(60, TimeUnit.SECONDS);
		driver.manage().window().maximize();
		HomePage.OneWay(driver).click();
	}
	
		//This will scroll the page till the element is found		
//		js.executeScript("arguments[0].scrollIntoView();",HomePage.AllAboutPersonalLoans(driver));
		
		//Search Flights
	@Test
	public void Searchflight()
	{
		JavascriptExecutor js = (JavascriptExecutor) driver;
		js.executeScript("arguments[0].scrollIntoView();",HomePage.SearchBtn(driver));
		driver.manage().timeouts().implicitlyWait(2, TimeUnit.SECONDS);
		HomePage.Origin(driver).sendKeys("BOS");
		HomePage.Destination(driver).sendKeys("ISP");
//		driver.manage().timeouts().implicitlyWait(10, TimeUnit.SECONDS);
		HomePage.DepartDate(driver).click();
		driver.manage().timeouts().implicitlyWait(5, TimeUnit.SECONDS);
		HomePage.DepartCal(driver).click();
		driver.manage().timeouts().implicitlyWait(5, TimeUnit.SECONDS);
		HomePage.SearchBtn(driver).click();
		driver.manage().timeouts().implicitlyWait(10, TimeUnit.SECONDS);
	}
	@AfterTest
	public void close()
	{
		driver.quit();
	}

}
