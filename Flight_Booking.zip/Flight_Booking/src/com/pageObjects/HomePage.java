package com.pageObjects;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;

public class HomePage {
	private static WebElement element = null;

	public static WebElement Origin(WebDriver driver){
	element = driver.findElement(By.id("LandingPageAirSearchForm_originationAirportCode"));
	return element;

	}
	public static WebElement Destination(WebDriver driver){
		element = driver.findElement(By.id("LandingPageAirSearchForm_destinationAirportCode"));
		return element;

	}
	public static WebElement DepartDate(WebDriver driver){
		element = driver.findElement(By.id("LandingPageAirSearchForm_departureDate"));
		return element;

	}
	public static WebElement OneWay(WebDriver driver){
		element = driver.findElement(By.cssSelector("input[value='oneway']"));
		return element;

	}
	public static WebElement NoOfAdults(WebDriver driver){
		element = driver.findElement(By.id("LandingPageAirSearchForm_adultPassengersCount"));
		return element;

	}
	public static WebElement SearchBtn(WebDriver driver){
		element = driver.findElement(By.id("LandingPageAirSearchForm_submit-button"));
		return element;

	}
	public static WebElement DepartSel(WebDriver driver){
		element = driver.findElement(By.className("fare-button--value-total"));
		return element;

	}
	
	public static WebElement DepartCal(WebDriver driver){
		element = driver.findElement(By.cssSelector("button[aria-label='Monday, June 3 2019']"));
		return element;

	}
	public static WebElement ArriveCal(WebDriver driver){
		element = driver.findElement(By.id("calendar-256-2019-06-04"));
		return element;

	}
}
